# Fishing Tide BI 6県MAP対応版

スマホで1ページ固定表示する釣り向けタイドグラフWebアプリです。

## 対応範囲
- 静岡県
- 愛知県
- 三重県
- 和歌山県
- 福井県
- 石川県

## 機能
- 1ページ固定のタイドグラフ
- 時間別の天気・風向・風速・波高表示
- 釣り指数とおすすめ時間帯
- 9地点のマイポイント切替
- MAP画面で釣り場ピンを選び登録
- 現在地から近い順表示
- Googleマップで開くボタン
- ホーム画面追加用PWA設定

## GitHub Pagesに置くファイル
以下をリポジトリ直下へアップしてください。

```text
index.html
style.css
script.js
manifest.webmanifest
icon.png
icon-192.png
icon-512.png
apple-touch-icon.png
```

## 注意
天気・風はOpen-Meteo Forecast API、波・水温はOpen-Meteo Marine APIを使用します。
潮位グラフは現在、月齢と地点別係数による簡易推算です。正式な潮汐APIに接続すると精度を上げられます。
釣り場の緯度経度は初期データです。実釣前は現地ルール・立入可否・駐車可否を確認してください。
