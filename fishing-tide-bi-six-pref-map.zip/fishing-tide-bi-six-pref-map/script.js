'use strict';

const PREFS = ['愛知県','三重県','静岡県','和歌山県','福井県','石川県'];
const TYPES = ['すべて','港','河口','サーフ','海釣り公園','堤防'];

const SPOTS = [
  // 愛知県
  {name:'名古屋港', prefecture:'愛知県', area:'名古屋市', type:'港', lat:35.073, lon:136.881, amp:67, base:132, phase:.15},
  {name:'山崎川河口', prefecture:'愛知県', area:'名古屋市', type:'河口', lat:35.080, lon:136.884, amp:65, base:130, phase:.15},
  {name:'新舞子', prefecture:'愛知県', area:'知多市', type:'堤防', lat:34.949, lon:136.825, amp:62, base:126, phase:.08},
  {name:'常滑港', prefecture:'愛知県', area:'常滑市', type:'港', lat:34.887, lon:136.831, amp:60, base:124, phase:.04},
  {name:'りんくう釣り護岸', prefecture:'愛知県', area:'常滑市', type:'堤防', lat:34.886, lon:136.823, amp:60, base:124, phase:.04},
  {name:'碧南海釣り広場', prefecture:'愛知県', area:'碧南市', type:'海釣り公園', lat:34.844, lon:136.980, amp:58, base:121, phase:-.02},
  {name:'衣浦港', prefecture:'愛知県', area:'半田市', type:'港', lat:34.876, lon:136.960, amp:60, base:123, phase:-.02},
  {name:'亀崎港', prefecture:'愛知県', area:'半田市', type:'港', lat:34.922, lon:136.962, amp:61, base:124, phase:-.01},
  {name:'一色漁港', prefecture:'愛知県', area:'西尾市', type:'港', lat:34.789, lon:137.014, amp:56, base:118, phase:-.10},
  {name:'西浦港', prefecture:'愛知県', area:'蒲郡市', type:'港', lat:34.778, lon:137.176, amp:55, base:115, phase:-.18},
  {name:'豊浜釣り桟橋', prefecture:'愛知県', area:'南知多町', type:'海釣り公園', lat:34.702, lon:136.927, amp:55, base:113, phase:-.18},
  {name:'師崎港', prefecture:'愛知県', area:'南知多町', type:'港', lat:34.700, lon:136.974, amp:54, base:112, phase:-.20},
  {name:'伊良湖港', prefecture:'愛知県', area:'田原市', type:'港', lat:34.584, lon:137.018, amp:52, base:105, phase:-.35},
  {name:'赤羽根港', prefecture:'愛知県', area:'田原市', type:'港', lat:34.609, lon:137.198, amp:50, base:103, phase:-.55},
  {name:'小松原海岸', prefecture:'愛知県', area:'豊橋市', type:'サーフ', lat:34.676, lon:137.394, amp:48, base:100, phase:-.72},
  {name:'伊古部海岸', prefecture:'愛知県', area:'豊橋市', type:'サーフ', lat:34.668, lon:137.437, amp:48, base:100, phase:-.74},
  {name:'表浜海岸', prefecture:'愛知県', area:'豊橋市', type:'サーフ', lat:34.667, lon:137.465, amp:48, base:100, phase:-.76},
  {name:'佐久島西港', prefecture:'愛知県', area:'西尾市', type:'港', lat:34.728, lon:137.037, amp:54, base:114, phase:-.14},

  // 三重県
  {name:'鈴鹿漁港', prefecture:'三重県', area:'鈴鹿市', type:'港', lat:34.840, lon:136.606, amp:64, base:124, phase:.18},
  {name:'白子漁港', prefecture:'三重県', area:'鈴鹿市', type:'港', lat:34.833, lon:136.600, amp:64, base:123, phase:.18},
  {name:'千代崎漁港', prefecture:'三重県', area:'鈴鹿市', type:'港', lat:34.857, lon:136.616, amp:64, base:124, phase:.18},
  {name:'四日市港', prefecture:'三重県', area:'四日市市', type:'港', lat:34.948, lon:136.653, amp:66, base:130, phase:.22},
  {name:'霞ヶ浦ふ頭', prefecture:'三重県', area:'四日市市', type:'堤防', lat:34.982, lon:136.660, amp:66, base:130, phase:.22},
  {name:'磯津漁港', prefecture:'三重県', area:'四日市市', type:'港', lat:34.905, lon:136.640, amp:65, base:128, phase:.20},
  {name:'長良川河口', prefecture:'三重県', area:'桑名市', type:'河口', lat:35.049, lon:136.700, amp:68, base:136, phase:.25},
  {name:'木曽川河口', prefecture:'三重県', area:'桑名市', type:'河口', lat:35.041, lon:136.722, amp:68, base:136, phase:.25},
  {name:'津ヨットハーバー', prefecture:'三重県', area:'津市', type:'堤防', lat:34.704, lon:136.534, amp:62, base:116, phase:.05},
  {name:'香良洲海岸', prefecture:'三重県', area:'津市', type:'サーフ', lat:34.661, lon:136.537, amp:60, base:114, phase:0},
  {name:'日本鋼管突堤', prefecture:'三重県', area:'津市', type:'堤防', lat:34.641, lon:136.541, amp:60, base:113, phase:-.02},
  {name:'松阪港', prefecture:'三重県', area:'松阪市', type:'港', lat:34.589, lon:136.570, amp:59, base:112, phase:-.05},
  {name:'鳥羽港', prefecture:'三重県', area:'鳥羽市', type:'港', lat:34.486, lon:136.846, amp:52, base:106, phase:-.22},
  {name:'答志島', prefecture:'三重県', area:'鳥羽市', type:'堤防', lat:34.520, lon:136.891, amp:51, base:105, phase:-.25},
  {name:'古和浦', prefecture:'三重県', area:'南伊勢町', type:'港', lat:34.229, lon:136.521, amp:48, base:100, phase:-.45},
  {name:'尾鷲港', prefecture:'三重県', area:'尾鷲市', type:'港', lat:34.072, lon:136.208, amp:46, base:96, phase:-.60},
  {name:'熊野大泊海岸', prefecture:'三重県', area:'熊野市', type:'サーフ', lat:33.900, lon:136.124, amp:45, base:95, phase:-.70},

  // 静岡県
  {name:'浜名湖新居', prefecture:'静岡県', area:'湖西市', type:'海釣り公園', lat:34.690, lon:137.563, amp:46, base:94, phase:-.75},
  {name:'新居海釣公園', prefecture:'静岡県', area:'湖西市', type:'海釣り公園', lat:34.689, lon:137.564, amp:46, base:94, phase:-.75},
  {name:'今切口', prefecture:'静岡県', area:'湖西市', type:'堤防', lat:34.682, lon:137.591, amp:47, base:95, phase:-.78},
  {name:'舞阪港', prefecture:'静岡県', area:'浜松市', type:'港', lat:34.682, lon:137.617, amp:47, base:95, phase:-.80},
  {name:'弁天島', prefecture:'静岡県', area:'浜松市', type:'堤防', lat:34.693, lon:137.604, amp:47, base:95, phase:-.78},
  {name:'天竜川河口', prefecture:'静岡県', area:'浜松市', type:'河口', lat:34.650, lon:137.817, amp:50, base:100, phase:-1.06},
  {name:'福田漁港', prefecture:'静岡県', area:'磐田市', type:'港', lat:34.670, lon:137.922, amp:50, base:100, phase:-1.15},
  {name:'太田川河口', prefecture:'静岡県', area:'磐田市', type:'河口', lat:34.666, lon:137.905, amp:50, base:100, phase:-1.15},
  {name:'御前崎港', prefecture:'静岡県', area:'御前崎市', type:'港', lat:34.605, lon:138.218, amp:48, base:98, phase:-1.35},
  {name:'相良海岸', prefecture:'静岡県', area:'牧之原市', type:'サーフ', lat:34.689, lon:138.219, amp:48, base:98, phase:-1.30},
  {name:'焼津港', prefecture:'静岡県', area:'焼津市', type:'港', lat:34.866, lon:138.327, amp:46, base:96, phase:-1.45},
  {name:'用宗港', prefecture:'静岡県', area:'静岡市', type:'港', lat:34.920, lon:138.361, amp:46, base:96, phase:-1.50},
  {name:'清水港', prefecture:'静岡県', area:'静岡市', type:'港', lat:35.019, lon:138.502, amp:44, base:94, phase:-1.55},
  {name:'三保海岸', prefecture:'静岡県', area:'静岡市', type:'サーフ', lat:35.000, lon:138.522, amp:44, base:94, phase:-1.55},
  {name:'沼津港', prefecture:'静岡県', area:'沼津市', type:'港', lat:35.084, lon:138.860, amp:42, base:90, phase:-1.80},
  {name:'静浦港', prefecture:'静岡県', area:'沼津市', type:'港', lat:35.034, lon:138.898, amp:42, base:90, phase:-1.82},
  {name:'熱海港', prefecture:'静岡県', area:'熱海市', type:'港', lat:35.095, lon:139.076, amp:40, base:88, phase:-1.96},
  {name:'伊東港', prefecture:'静岡県', area:'伊東市', type:'港', lat:34.973, lon:139.099, amp:40, base:88, phase:-2.0},

  // 和歌山県
  {name:'紀ノ川河口', prefecture:'和歌山県', area:'和歌山市', type:'河口', lat:34.230, lon:135.117, amp:52, base:103, phase:.35},
  {name:'青岸', prefecture:'和歌山県', area:'和歌山市', type:'堤防', lat:34.218, lon:135.133, amp:52, base:103, phase:.34},
  {name:'加太港', prefecture:'和歌山県', area:'和歌山市', type:'港', lat:34.277, lon:135.072, amp:50, base:101, phase:.30},
  {name:'田ノ浦漁港', prefecture:'和歌山県', area:'和歌山市', type:'港', lat:34.185, lon:135.164, amp:52, base:102, phase:.30},
  {name:'雑賀崎漁港', prefecture:'和歌山県', area:'和歌山市', type:'港', lat:34.188, lon:135.148, amp:52, base:102, phase:.30},
  {name:'和歌山マリーナシティ', prefecture:'和歌山県', area:'和歌山市', type:'海釣り公園', lat:34.153, lon:135.179, amp:52, base:102, phase:.27},
  {name:'海南港', prefecture:'和歌山県', area:'海南市', type:'港', lat:34.158, lon:135.203, amp:52, base:102, phase:.25},
  {name:'下津港', prefecture:'和歌山県', area:'海南市', type:'港', lat:34.113, lon:135.153, amp:51, base:101, phase:.22},
  {name:'有田川河口', prefecture:'和歌山県', area:'有田市', type:'河口', lat:34.083, lon:135.106, amp:50, base:100, phase:.20},
  {name:'湯浅広港', prefecture:'和歌山県', area:'湯浅町', type:'港', lat:34.035, lon:135.167, amp:50, base:100, phase:.16},
  {name:'由良海つり公園', prefecture:'和歌山県', area:'由良町', type:'海釣り公園', lat:33.977, lon:135.088, amp:49, base:99, phase:.08},
  {name:'日高港', prefecture:'和歌山県', area:'御坊市', type:'港', lat:33.882, lon:135.152, amp:48, base:98, phase:0},
  {name:'煙樹ヶ浜', prefecture:'和歌山県', area:'美浜町', type:'サーフ', lat:33.886, lon:135.104, amp:48, base:98, phase:0},
  {name:'天神崎', prefecture:'和歌山県', area:'田辺市', type:'堤防', lat:33.725, lon:135.340, amp:46, base:96, phase:-.18},
  {name:'串本港', prefecture:'和歌山県', area:'串本町', type:'港', lat:33.472, lon:135.784, amp:44, base:94, phase:-.55},
  {name:'勝浦港', prefecture:'和歌山県', area:'那智勝浦町', type:'港', lat:33.625, lon:135.941, amp:44, base:94, phase:-.68},

  // 福井県
  {name:'敦賀新港', prefecture:'福井県', area:'敦賀市', type:'港', lat:35.672, lon:136.064, amp:22, base:38, phase:.20},
  {name:'敦賀港', prefecture:'福井県', area:'敦賀市', type:'港', lat:35.657, lon:136.073, amp:22, base:38, phase:.20},
  {name:'気比の松原', prefecture:'福井県', area:'敦賀市', type:'サーフ', lat:35.651, lon:136.055, amp:22, base:38, phase:.18},
  {name:'菅浜漁港', prefecture:'福井県', area:'美浜町', type:'港', lat:35.646, lon:135.944, amp:21, base:37, phase:.12},
  {name:'日向湖', prefecture:'福井県', area:'美浜町', type:'堤防', lat:35.616, lon:135.896, amp:21, base:37, phase:.08},
  {name:'小浜港', prefecture:'福井県', area:'小浜市', type:'港', lat:35.492, lon:135.746, amp:21, base:37, phase:-.04},
  {name:'阿納漁港', prefecture:'福井県', area:'小浜市', type:'港', lat:35.542, lon:135.727, amp:21, base:37, phase:-.05},
  {name:'若狭大島', prefecture:'福井県', area:'おおい町', type:'堤防', lat:35.525, lon:135.645, amp:21, base:36, phase:-.08},
  {name:'音海大波止', prefecture:'福井県', area:'高浜町', type:'堤防', lat:35.526, lon:135.507, amp:21, base:36, phase:-.14},
  {name:'高浜漁港', prefecture:'福井県', area:'高浜町', type:'港', lat:35.495, lon:135.551, amp:21, base:36, phase:-.12},
  {name:'越前海岸', prefecture:'福井県', area:'越前町', type:'堤防', lat:35.974, lon:135.977, amp:22, base:38, phase:.28},
  {name:'梅浦漁港', prefecture:'福井県', area:'越前町', type:'港', lat:35.963, lon:135.965, amp:22, base:38, phase:.26},
  {name:'鷹巣漁港', prefecture:'福井県', area:'福井市', type:'港', lat:36.102, lon:136.060, amp:23, base:39, phase:.35},
  {name:'三国港', prefecture:'福井県', area:'坂井市', type:'港', lat:36.217, lon:136.145, amp:23, base:40, phase:.42},
  {name:'九頭竜川河口', prefecture:'福井県', area:'坂井市', type:'河口', lat:36.224, lon:136.147, amp:23, base:40, phase:.42},

  // 石川県
  {name:'金沢港', prefecture:'石川県', area:'金沢市', type:'港', lat:36.616, lon:136.603, amp:24, base:42, phase:.52},
  {name:'大野川河口', prefecture:'石川県', area:'金沢市', type:'河口', lat:36.608, lon:136.601, amp:24, base:42, phase:.52},
  {name:'犀川河口', prefecture:'石川県', area:'金沢市', type:'河口', lat:36.586, lon:136.585, amp:24, base:42, phase:.50},
  {name:'内灘放水路', prefecture:'石川県', area:'内灘町', type:'河口', lat:36.653, lon:136.625, amp:24, base:42, phase:.55},
  {name:'手取川河口', prefecture:'石川県', area:'白山市', type:'河口', lat:36.516, lon:136.522, amp:24, base:41, phase:.48},
  {name:'安宅海岸', prefecture:'石川県', area:'小松市', type:'サーフ', lat:36.406, lon:136.408, amp:23, base:41, phase:.42},
  {name:'橋立漁港', prefecture:'石川県', area:'加賀市', type:'港', lat:36.330, lon:136.315, amp:23, base:40, phase:.36},
  {name:'千里浜', prefecture:'石川県', area:'羽咋市', type:'サーフ', lat:36.913, lon:136.779, amp:24, base:42, phase:.65},
  {name:'七尾港', prefecture:'石川県', area:'七尾市', type:'港', lat:37.047, lon:136.963, amp:19, base:35, phase:.72},
  {name:'能登島', prefecture:'石川県', area:'七尾市', type:'堤防', lat:37.126, lon:136.999, amp:19, base:35, phase:.75},
  {name:'穴水湾', prefecture:'石川県', area:'穴水町', type:'港', lat:37.229, lon:136.906, amp:19, base:35, phase:.77},
  {name:'富来漁港', prefecture:'石川県', area:'志賀町', type:'港', lat:37.141, lon:136.716, amp:22, base:39, phase:.75},
  {name:'輪島港', prefecture:'石川県', area:'輪島市', type:'港', lat:37.401, lon:136.900, amp:22, base:39, phase:.88},
  {name:'宇出津港', prefecture:'石川県', area:'能登町', type:'港', lat:37.306, lon:137.148, amp:20, base:36, phase:.92},
  {name:'珠洲飯田港', prefecture:'石川県', area:'珠洲市', type:'港', lat:37.436, lon:137.262, amp:20, base:36, phase:1.0}
];

const INITIAL_NAMES = ['名古屋港','鈴鹿漁港','四日市港','長良川河口','新舞子','赤羽根港','伊古部海岸','浜名湖新居','天竜川河口'];
const DEFAULT_POINTS = INITIAL_NAMES.map(n => ({...SPOTS.find(s => s.name === n)}));
const $ = id => document.getElementById(id);

const state = {
  points: loadPoints(),
  selectedName: localStorage.getItem('ftbi.selected') || '名古屋港',
  favorites: new Set(JSON.parse(localStorage.getItem('ftbi.favorites') || '["名古屋港"]')),
  dateOffset: 0,
  weather: null,
  marine: null,
  map: null,
  markers: [],
  mapPref: '愛知県',
  mapType: 'すべて',
  chosenSpot: null,
  userLocation: null
};

function loadPoints(){
  try {
    const raw = JSON.parse(localStorage.getItem('ftbi.points'));
    if(Array.isArray(raw) && raw.length) return raw;
  } catch(e) {}
  return DEFAULT_POINTS;
}
function savePoints(){ localStorage.setItem('ftbi.points', JSON.stringify(state.points)); }
function saveFavs(){ localStorage.setItem('ftbi.favorites', JSON.stringify([...state.favorites])); }
function selectedPoint(){ return state.points.find(p=>p.name===state.selectedName) || state.points[0] || DEFAULT_POINTS[0]; }
function selectedDate(){ const d = new Date(); d.setDate(d.getDate()+state.dateOffset); d.setHours(0,0,0,0); return d; }
function ymd(d){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function fmtDate(d){ const w='日月火水木金土'[d.getDay()]; return `${d.getMonth()+1}月${d.getDate()}日(${w})`; }
function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }
function hm(hour){ let h=Math.floor(hour)%24; let m=Math.round((hour-Math.floor(hour))*60); if(m===60){h=(h+1)%24;m=0;} return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`; }
function currentHour(){ if(state.dateOffset!==0) return 12; const d=new Date(); return d.getHours()+d.getMinutes()/60; }
function degDistanceKm(aLat,aLon,bLat,bLon){ const R=6371; const toRad=x=>x*Math.PI/180; const dLat=toRad(bLat-aLat); const dLon=toRad(bLon-aLon); const aa=Math.sin(dLat/2)**2+Math.cos(toRad(aLat))*Math.cos(toRad(bLat))*Math.sin(dLon/2)**2; return R*2*Math.atan2(Math.sqrt(aa),Math.sqrt(1-aa)); }

function moonAge(date){
  const synodic=29.530588853;
  const ref=Date.UTC(2000,0,6,18,14,0);
  const days=(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate(),12)-ref)/86400000;
  return ((days%synodic)+synodic)%synodic;
}
function tideClass(age){
  if(age<1.5||age>28||(age>13.2&&age<16.2)) return '大潮';
  if((age>=9.5&&age<10.8)||(age>=24.2&&age<25.5)) return '長潮';
  if((age>=10.8&&age<12.2)||(age>=25.5&&age<27)) return '若潮';
  if((age>=6.7&&age<9.5)||(age>=21.4&&age<24.2)) return '小潮';
  return '中潮';
}
function tideFactor(age){ const spring=(Math.cos(2*Math.PI*age/14.765)+1)/2; return 0.62+spring*0.55; }
function tideHeight(p,hour,age){ const amp=(p.amp||50)*tideFactor(age); const h=hour+(p.phase||0)+age*.78; return (p.base||100)+amp*(Math.sin(2*Math.PI*h/12.42)+.22*Math.sin(2*Math.PI*(h-2.4)/24)); }
function tideSeries(p,date){
  const age=moonAge(date); const data=[];
  for(let h=0;h<=24.001;h+=.25) data.push({hour:h,height:tideHeight(p,h,age)});
  const extrema=[];
  for(let i=1;i<data.length-1;i++){
    const prev=data[i-1].height, cur=data[i].height, next=data[i+1].height;
    if(cur>=prev&&cur>=next) extrema.push({...data[i],type:'high'});
    if(cur<=prev&&cur<=next) extrema.push({...data[i],type:'low'});
  }
  return {age,data,extrema};
}
function sunTimes(date, lon){
  const start=new Date(date.getFullYear(),0,0); const n=Math.floor((date-start)/86400000);
  const seasonal=-.75*Math.cos((n-172)/365*2*Math.PI);
  const sunrise=5.02+seasonal-(lon-136.8)*.03;
  const sunset=18.15-seasonal-(lon-136.8)*.03;
  return {sunrise:clamp(sunrise,4.4,7.1),sunset:clamp(sunset,16.8,19.3)};
}
function moonTimes(age){ const rise=(6+age*.82)%24; return {rise,set:(rise+12.2)%24}; }
function weatherIcon(code,hour){
  if(code===0) return hour>=18||hour<5?'🌙':'☀️';
  if([1,2].includes(code)) return hour>=18||hour<5?'🌙':'🌤️';
  if(code===3) return '☁️';
  if([45,48].includes(code)) return '🌫️';
  if([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code)) return '🌧️';
  if([71,73,75,77,85,86].includes(code)) return '❄️';
  if([95,96,99].includes(code)) return '⛈️';
  return '☁️';
}
function weatherText(code){
  if(code===0) return '晴れ'; if([1,2].includes(code)) return '晴れ時々くもり'; if(code===3) return 'くもり';
  if([45,48].includes(code)) return '霧'; if([51,53,55].includes(code)) return '小雨';
  if([61,63,65,80,81,82].includes(code)) return '雨'; if([95,96,99].includes(code)) return '雷雨';
  return 'くもり';
}
function compass(deg){
  if(deg==null || Number.isNaN(deg)) return '--';
  const dirs=['北','北北東','北東','東北東','東','東南東','南東','南南東','南','南南西','南西','西南西','西','西北西','北西','北北西'];
  return dirs[Math.round(deg/22.5)%16];
}
function shortDir(deg){ const d=compass(deg); return d.replace('北北','北').replace('南南','南').replace('東北','東').replace('東南','東').replace('西北','西').replace('西南','西'); }
function svgEl(name,attrs={}){ const el=document.createElementNS('http://www.w3.org/2000/svg',name); Object.entries(attrs).forEach(([k,v])=>el.setAttribute(k,v)); return el; }
function linePath(points){ return points.map((p,i)=>`${i?'L':'M'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' '); }

function drawTide(tide){
  const svg=$('tideSvg'); svg.innerHTML='';
  const W=390,H=255, L=42,R=16,T=16,B=28; const plotW=W-L-R, plotH=H-T-B;
  const vals=tide.data.map(d=>d.height); const min=Math.floor((Math.min(...vals)-20)/50)*50; const max=Math.ceil((Math.max(...vals)+20)/50)*50;
  const x=h=>L+(h/24)*plotW; const y=v=>T+(max-v)/(max-min)*plotH;
  svg.append(svgEl('rect',{x:0,y:0,width:W,height:H,fill:'transparent'}));
  for(let cm=min;cm<=max;cm+=50){ const yy=y(cm); svg.append(svgEl('line',{x1:L,y1:yy,x2:W-R,y2:yy,stroke:'rgba(255,255,255,.18)','stroke-dasharray':'3 4'})); const tx=svgEl('text',{x:6,y:yy+4,class:'axisText'}); tx.textContent=`${cm}cm`; svg.append(tx); }
  for(let h=0;h<=24;h+=3){ const xx=x(h); svg.append(svgEl('line',{x1:xx,y1:T,x2:xx,y2:H-B,stroke:'rgba(255,255,255,.18)','stroke-dasharray': h%6===0?'':'4 5'})); const tx=svgEl('text',{x:xx-6,y:H-8,class:'axisText'}); tx.textContent=h===24?'24時':String(h); svg.append(tx); }
  svg.append(svgEl('path',{d:linePath(tide.data.map(d=>({x:x(d.hour),y:y(d.height)})))+` L ${x(24)} ${H-B} L ${x(0)} ${H-B} Z`,fill:'rgba(20,205,236,.25)'}));
  svg.append(svgEl('path',{d:linePath(tide.data.map(d=>({x:x(d.hour),y:y(d.height)}))),fill:'none',stroke:'#35e6ff','stroke-width':4,'stroke-linecap':'round','stroke-linejoin':'round'}));
  const p=selectedPoint(); const sun=sunTimes(selectedDate(),p.lon); const moon=moonTimes(tide.age);
  [{h:sun.sunrise,c:'#ffd84a',label:'☀'}, {h:sun.sunset,c:'#ff8b2a',label:'🌇'}, {h:moon.rise,c:'#dff2ff',label:'☾'}].forEach(m=>{ const xx=x(m.h); svg.append(svgEl('rect',{x:xx-11,y:T,width:22,height:plotH,fill:m.c,opacity:.14})); svg.append(svgEl('line',{x1:xx,y1:T,x2:xx,y2:H-B,stroke:m.c,'stroke-dasharray':'3 4','stroke-width':1.2})); const t=svgEl('text',{x:xx-8,y:T+13,class:'axisText'}); t.textContent=m.label; svg.append(t); });
  svg.append(svgEl('circle',{cx:x(currentHour()),cy:y(tideHeight(p,currentHour(),tide.age)),r:9,fill:'#ff2e31',stroke:'#fff','stroke-width':3}));
  const curX=x(currentHour()), curY=y(tideHeight(p,currentHour(),tide.age));
  const g=svgEl('g'); g.append(svgEl('rect',{x:clamp(curX+10,L,W-72),y:clamp(curY-38,T,H-68),width:62,height:42,rx:6,fill:'#ff2e31',stroke:'#fff'})); let t=svgEl('text',{x:clamp(curX+41,L+31,W-41),y:clamp(curY-20,T+18,H-50),class:'currentText','text-anchor':'middle'}); t.textContent='現在'; g.append(t); t=svgEl('text',{x:clamp(curX+41,L+31,W-41),y:clamp(curY-4,T+34,H-34),class:'currentText','text-anchor':'middle'}); t.textContent=`${Math.round(tideHeight(p,currentHour(),tide.age))}cm`; g.append(t); svg.append(g);
  tide.extrema.slice(0,4).forEach(e=>{ const xx=x(e.hour), yy=y(e.height); svg.append(svgEl('circle',{cx:xx,cy:yy,r:6,fill:e.type==='high'?'#145bc3':'#062b50',stroke:'#fff','stroke-width':2})); const bw=58,bh=35,bx=clamp(xx-bw/2,L,W-R-bw),by=e.type==='high'?clamp(yy-43,T,H-B-bh):clamp(yy+9,T,H-B-bh); const gg=svgEl('g'); gg.append(svgEl('rect',{x:bx,y:by,width:bw,height:bh,rx:6,fill:e.type==='high'?'#126ce0':'#eaf6ff',stroke:'#70c8ff','stroke-width':1.5})); let tt=svgEl('text',{x:bx+bw/2,y:by+14,class:e.type==='high'?'calloutTime':'calloutCm','text-anchor':'middle'}); tt.textContent=hm(e.hour); gg.append(tt); tt=svgEl('text',{x:bx+bw/2,y:by+29,class:e.type==='high'?'calloutTime':'calloutCm','text-anchor':'middle'}); tt.textContent=`${Math.round(e.height)}cm`; gg.append(tt); svg.append(gg); });
  for(let i=0;i<8;i++){ const fx=L+12+i*38, fy=H-B-18-(i%3)*10; svg.append(svgEl('path',{class:'fish',d:`M${fx} ${fy} q14 -8 28 0 q-14 8 -28 0 M${fx+26} ${fy} l8 -6 v12 z`})); }
}

function nearestHourly(hourly,key,hour){
  if(!hourly || !hourly.time || !hourly[key]) return null;
  const target=`${ymd(selectedDate())}T${String(Math.min(23,Math.floor(hour))).padStart(2,'0')}:00`;
  let idx=hourly.time.indexOf(target); if(idx<0) idx=Math.min(hourly[key].length-1,Math.max(0,Math.round(hour)));
  return hourly[key][idx];
}
function fallbackWeather(p){
  const date=ymd(selectedDate());
  const wh={time:[],temperature_2m:[],relative_humidity_2m:[],precipitation:[],weather_code:[],wind_speed_10m:[],wind_direction_10m:[],wind_gusts_10m:[],surface_pressure:[]};
  const mh={time:[],wave_height:[],wave_direction:[],sea_surface_temperature:[]};
  for(let h=0;h<24;h++){
    wh.time.push(`${date}T${String(h).padStart(2,'0')}:00`);
    wh.temperature_2m.push(+(23+4*Math.sin((h-7)/24*2*Math.PI)+(p.prefecture==='静岡県'?1:0)).toFixed(1));
    wh.relative_humidity_2m.push(Math.round(70-8*Math.sin((h-8)/24*2*Math.PI)));
    wh.precipitation.push(0); wh.weather_code.push(h>18||h<5?1:2);
    wh.wind_speed_10m.push(+(3.5+2.1*Math.sin((h-10)/24*2*Math.PI)).toFixed(1));
    wh.wind_direction_10m.push(150+50*Math.sin(h/24*2*Math.PI)); wh.wind_gusts_10m.push(+(5+2*Math.sin((h-10)/24*2*Math.PI)).toFixed(1)); wh.surface_pressure.push(1015);
    mh.time.push(wh.time[h]); mh.wave_height.push(+(p.prefecture==='愛知県'?0.25:p.prefecture==='三重県'?0.35:p.prefecture==='静岡県'?0.45:0.5).toFixed(1)); mh.wave_direction.push(150); mh.sea_surface_temperature.push(+(23+1.2*Math.sin((h-8)/24*2*Math.PI)).toFixed(1));
  }
  return {weather:{hourly:wh},marine:{hourly:mh}};
}
async function fetchData(p){
  const date=ymd(selectedDate());
  const wParams=new URLSearchParams({latitude:p.lat,longitude:p.lon,timezone:'Asia/Tokyo',start_date:date,end_date:date,hourly:'temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure'});
  const mParams=new URLSearchParams({latitude:p.lat,longitude:p.lon,timezone:'Asia/Tokyo',start_date:date,end_date:date,hourly:'wave_height,wave_direction,sea_surface_temperature'});
  try{
    const [w,m]=await Promise.all([fetch(`https://api.open-meteo.com/v1/forecast?${wParams}`,{cache:'no-store'}),fetch(`https://marine-api.open-meteo.com/v1/marine?${mParams}`,{cache:'no-store'})]);
    if(!w.ok||!m.ok) throw new Error('api');
    state.weather=await w.json(); state.marine=await m.json();
  }catch(e){ const fb=fallbackWeather(p); state.weather=fb.weather; state.marine=fb.marine; }
}
function hourlyValues(hour){
  const wh=state.weather?.hourly||{}, mh=state.marine?.hourly||{};
  return {temp:nearestHourly(wh,'temperature_2m',hour),hum:nearestHourly(wh,'relative_humidity_2m',hour),rain:nearestHourly(wh,'precipitation',hour),code:nearestHourly(wh,'weather_code',hour),wind:nearestHourly(wh,'wind_speed_10m',hour),dir:nearestHourly(wh,'wind_direction_10m',hour),gust:nearestHourly(wh,'wind_gusts_10m',hour),pressure:nearestHourly(wh,'surface_pressure',hour),wave:nearestHourly(mh,'wave_height',hour),water:nearestHourly(mh,'sea_surface_temperature',hour),waveDir:nearestHourly(mh,'wave_direction',hour)};
}
function scoreAt(hour,tide){
  const v=hourlyValues(hour), p=selectedPoint();
  const move=Math.abs(tideHeight(p,Math.min(24,hour+1),tide.age)-tideHeight(p,hour,tide.age));
  const sun=sunTimes(selectedDate(),p.lon);
  let s=38; s+=clamp(move/18,0,1)*24; s+=Math.max(0,1-Math.min(Math.abs(hour-sun.sunrise),Math.abs(hour-sun.sunset))/2.2)*18;
  s+=(v.wind??3)<=5?13:(v.wind<=8?4:-10); s+=(v.wave??.3)<=.6?13:(v.wave<=1?5:-8); s+=(v.rain??0)<=.2?5:-8; s+=['大潮','中潮'].includes(tideClass(tide.age))?7:0;
  return Math.round(clamp(s,0,100));
}
function bestWindows(tide){
  const arr=[]; for(let h=0;h<24;h+=.5) arr.push({h,s:scoreAt(h,tide)});
  const picks=[]; for(const row of [...arr].sort((a,b)=>b.s-a.s)){ if(picks.every(p=>Math.abs(p.h-row.h)>4)) picks.push(row); if(picks.length===2) break; }
  return picks.map(p=>({start:clamp(p.h-1.25,0,23.5),end:clamp(p.h+1.25,.5,24),score:p.s})).sort((a,b)=>a.start-b.start);
}
function renderHourly(){
  const hours=[0,3,6,9,12,15,18,21,23]; const grid=$('hourlyGrid'); grid.innerHTML='';
  const heads=['時間','天気','風向','風速','波高','水温'];
  heads.forEach((h,r)=>{ const d=document.createElement('div'); d.textContent=h; d.className='rowHead'; grid.append(d); hours.forEach(hour=>{ const v=hourlyValues(hour); const c=document.createElement('div'); if(r===0){c.textContent=hour===23?'23':String(hour); c.className='hourCell'} if(r===1){c.textContent=weatherIcon(v.code,hour); c.className='weatherCell'} if(r===2){c.innerHTML=`<span class="arrow" style="transform:rotate(${v.dir||0}deg)">➤</span><small>${shortDir(v.dir)}</small>`; c.className='numCell'} if(r===3){c.textContent=`${(v.wind??0).toFixed(1)}`; c.className='numCell'} if(r===4){c.textContent=`${(v.wave??0).toFixed(1)}m`; c.className='waveCell'} if(r===5){c.textContent=`${(v.water??0).toFixed(1)}°`; c.className='tempCell'} grid.append(c); }); });
}
function renderPoints(){
  const grid=$('pointGrid'); grid.innerHTML='';
  state.points.slice(0,9).forEach(p=>{ const b=document.createElement('button'); b.className='pointBtn'+(p.name===state.selectedName?' active':''); b.innerHTML=`<span>${p.name}</span><small>${p.prefecture.replace('県','')}</small><i class="pin">${state.favorites.has(p.name)?'★':'☆'}</i>`; b.onclick=()=>{state.selectedName=p.name;localStorage.setItem('ftbi.selected',p.name); renderAll();}; grid.append(b); });
}
function renderManageList(){
  const list=$('manageList'); if(!list) return; list.innerHTML='';
  state.points.slice(0,9).forEach(p=>{ const row=document.createElement('div'); row.className='manageRow'; row.innerHTML=`<div class="manageName">${p.name}<small>　${p.prefecture} ${p.type||''}</small></div><button class="deleteBtn">削</button>`; row.querySelector('button').onclick=()=>{ state.points=state.points.filter(x=>x.name!==p.name); if(state.selectedName===p.name) state.selectedName=state.points[0]?.name||'名古屋港'; savePoints(); renderAll(); renderManageList(); }; list.append(row); });
}
async function renderAll(){
  const p=selectedPoint(); $('dateButton').textContent=fmtDate(selectedDate()); $('prefName').textContent=p.prefecture; $('pointName').textContent=p.name;
  $('favButton').textContent=state.favorites.has(p.name)?'★':'☆';
  const tide=tideSeries(p,selectedDate()); const ch=tideClass(tide.age); $('tideType').textContent=ch; $('moonAge').textContent=tide.age.toFixed(1);
  const sun=sunTimes(selectedDate(),p.lon), moon=moonTimes(tide.age); $('sunrise').textContent=hm(sun.sunrise); $('sunset').textContent=hm(sun.sunset); $('moonrise').textContent=hm(moon.rise); $('moonset').textContent=hm(moon.set);
  const cur=tideHeight(p,currentHour(),tide.age), prev=tideHeight(p,Math.max(0,currentHour()-1),tide.age); $('currentTide').textContent=`${Math.round(cur)}cm`; $('tideDiff').textContent=`${cur-prev>=0?'↑':'↓'}${Math.abs(cur-prev).toFixed(1)}`;
  drawTide(tide); renderPoints();
  await fetchData(p);
  const now=hourlyValues(currentHour()); $('weatherIcon').textContent=weatherIcon(now.code,currentHour()); $('weatherText').textContent=weatherText(now.code); $('temperature').textContent=`${(now.temp??0).toFixed(1)}℃`; $('windDir').textContent=compass(now.dir); $('windSpeed').textContent=`${(now.wind??0).toFixed(1)}m/s`; $('waveHeight').textContent=`${(now.wave??0).toFixed(1)}m`; $('waterTemp').textContent=`${(now.water??0).toFixed(1)}℃`;
  const wins=bestWindows(tide); $('bestTime1').textContent=wins[0]?`${hm(wins[0].start)}〜${hm(wins[0].end)}`:'--'; $('bestTime2').textContent=wins[1]?`${hm(wins[1].start)}〜${hm(wins[1].end)}`:'--'; const score=scoreAt(currentHour(),tide); $('scoreBadge').textContent=score;
  renderHourly(); renderManageList();
}

function filteredSpots(){
  let arr=SPOTS.filter(s=>s.prefecture===state.mapPref && (state.mapType==='すべて'||s.type===state.mapType));
  if(state.userLocation){ arr=arr.map(s=>({...s,distance:degDistanceKm(state.userLocation.lat,state.userLocation.lon,s.lat,s.lon)})).sort((a,b)=>a.distance-b.distance); }
  return arr;
}
function initMap(){
  if(state.map || !window.L) return;
  state.map=L.map('map',{zoomControl:true,attributionControl:false}).setView([34.85,136.9],8);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap'}).addTo(state.map);
  state.map.on('click',e=>{
    const custom={name:'地図で選択', prefecture:state.mapPref, area:'任意地点', type:'任意', lat:+e.latlng.lat.toFixed(6), lon:+e.latlng.lng.toFixed(6), amp:50, base:100, phase:0};
    chooseMapSpot(custom);
  });
}
function renderMapControls(){
  const pc=$('prefChips'); pc.innerHTML=''; PREFS.forEach(pref=>{ const b=document.createElement('button'); b.className='chip'+(pref===state.mapPref?' active':''); b.textContent=pref.replace('県',''); b.onclick=()=>{state.mapPref=pref; state.userLocation=null; renderMap();}; pc.append(b); });
  const tc=$('typeChips'); tc.innerHTML=''; TYPES.forEach(type=>{ const b=document.createElement('button'); b.className='chip'+(type===state.mapType?' active':''); b.textContent=type; b.onclick=()=>{state.mapType=type; renderMap();}; tc.append(b); });
}
function chooseMapSpot(s){
  state.chosenSpot={...s}; $('mapSpotName').textContent=s.name; $('mapSpotMeta').textContent=`${s.prefecture} ${s.area} ${s.type}${s.distance?`・約${s.distance.toFixed(1)}km`:''}`; $('registerMapSpot').disabled=false; $('openGoogleMap').disabled=false;
}
function renderMap(){
  renderMapControls(); initMap(); if(!state.map) return;
  setTimeout(()=>state.map.invalidateSize(),50);
  state.markers.forEach(m=>m.remove()); state.markers=[];
  const arr=filteredSpots(); const bounds=[];
  arr.forEach(s=>{
    const marker=L.marker([s.lat,s.lon]).addTo(state.map); marker.bindPopup(`<div class="popupTitle">${s.name}</div><div class="popupMeta">${s.prefecture} ${s.area}｜${s.type}</div><div class="popupBtns"><button class="popupReg" data-reg="${s.name}">登録</button><button class="popupMap" data-map="${s.name}">Google</button></div>`); marker.on('click',()=>chooseMapSpot(s)); state.markers.push(marker); bounds.push([s.lat,s.lon]);
  });
  if(bounds.length) state.map.fitBounds(bounds,{padding:[24,24],maxZoom:10});
  const list=$('spotList'); list.innerHTML='';
  arr.forEach(s=>{ const item=document.createElement('button'); item.className='spotItem'+(state.chosenSpot?.name===s.name?' active':''); item.innerHTML=`<div><b>${s.name}</b><span>${s.prefecture} ${s.area}｜${s.type}</span></div><span class="distance">${s.distance?`${s.distance.toFixed(1)}km`:''}</span>`; item.onclick=()=>{chooseMapSpot(s); if(state.map) state.map.setView([s.lat,s.lon],13);}; list.append(item); });
}
function registerSpot(s){
  const spot={...s}; if(!spot.amp){ spot.amp=50; spot.base=100; spot.phase=0; }
  const exists=state.points.findIndex(p=>p.name===spot.name);
  if(exists>=0){ state.points[exists]=spot; }
  else if(state.points.length<9){ state.points.push(spot); }
  else { const idx=Math.max(0,state.points.findIndex(p=>p.name===state.selectedName)); state.points[idx]=spot; }
  state.selectedName=spot.name; localStorage.setItem('ftbi.selected',spot.name); savePoints(); renderAll();
}
function googleMapUrl(s){ return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${s.name} ${s.prefecture} ${s.area}`)}`; }
function openMapDialog(){ $('mapDialog').showModal(); setTimeout(()=>{renderMap();},80); }
function openSettings(){ renderManageList(); $('settingsDialog').showModal(); }

function setupEvents(){
  $('prevDay').onclick=()=>{state.dateOffset=Math.max(-1,state.dateOffset-1); renderAll();};
  $('nextDay').onclick=()=>{state.dateOffset=Math.min(14,state.dateOffset+1); renderAll();};
  $('dateButton').onclick=()=>{ const steps=[0,1,3,7,14]; const i=steps.indexOf(state.dateOffset); state.dateOffset=steps[(i+1)%steps.length]; renderAll(); };
  $('favButton').onclick=()=>{ const p=selectedPoint(); state.favorites.has(p.name)?state.favorites.delete(p.name):state.favorites.add(p.name); saveFavs(); renderAll(); };
  $('mapOpen').onclick=openMapDialog; $('settingsOpen').onclick=openSettings; $('mapClose').onclick=()=>$('mapDialog').close();
  $('registerMapSpot').onclick=()=>{ if(state.chosenSpot){ registerSpot(state.chosenSpot); $('mapDialog').close(); }};
  $('openGoogleMap').onclick=()=>{ if(state.chosenSpot) window.open(googleMapUrl(state.chosenSpot),'_blank'); };
  $('nearButton').onclick=()=>{ if(!navigator.geolocation){ alert('位置情報が使えません'); return; } navigator.geolocation.getCurrentPosition(pos=>{ state.userLocation={lat:pos.coords.latitude,lon:pos.coords.longitude}; renderMap(); },()=>alert('位置情報を取得できませんでした'),{enableHighAccuracy:true,timeout:10000}); };
  $('mapDialog').addEventListener('click',e=>{ const r=e.target.closest('[data-reg]'), m=e.target.closest('[data-map]'); if(r){ const s=SPOTS.find(x=>x.name===r.dataset.reg); if(s){ registerSpot(s); $('mapDialog').close(); }} if(m){ const s=SPOTS.find(x=>x.name===m.dataset.map); if(s) window.open(googleMapUrl(s),'_blank'); }});
  $('resetPoints').onclick=()=>{ state.points=DEFAULT_POINTS.map(p=>({...p})); state.selectedName='名古屋港'; savePoints(); localStorage.setItem('ftbi.selected',state.selectedName); renderAll(); renderManageList(); };
}

setupEvents();
renderAll();
